class Config():
    learning_rate = 0.001
    res_blocks = 6
    mcts_iterations = 30
    epochs = 10
    self_plays = 10
    early_training = 10
    initial_temperature = 1
    final_temperature = 0.001
    alpha = 0.5
    epsilon = 0.25